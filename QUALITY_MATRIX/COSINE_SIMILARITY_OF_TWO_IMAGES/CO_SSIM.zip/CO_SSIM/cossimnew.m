function s=cossimnew(actual,estimate)
[m,n]=size(actual);
if n==1
  s=((estimate'*actual)/(norm(estimate)*norm(actual)))';
else
  for i=1:n,
    x=norm(estimate(:,i))*norm(actual(:,i));
    if x ~= 0
        s(i)=(estimate(:,i)'*actual(:,i))/x;
    else
      s(i)=NaN;
    end
  end
end
  s=s';