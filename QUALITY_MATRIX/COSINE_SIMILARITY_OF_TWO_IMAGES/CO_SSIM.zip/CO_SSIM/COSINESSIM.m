I1 = imread('baby_x2_GT.png');
I2 = imread('baby_x2_SRCNN.png');
IV1 = double(I1(:));
IV2 = double(I2(:));
cossimnew(IV1,IV2)