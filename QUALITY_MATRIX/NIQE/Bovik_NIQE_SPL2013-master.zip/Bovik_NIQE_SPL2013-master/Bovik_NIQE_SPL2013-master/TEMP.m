TRD 
MLP 
CSF 
WNNM 
ours 
NoiseClinic 
NeatImage 
BM3D