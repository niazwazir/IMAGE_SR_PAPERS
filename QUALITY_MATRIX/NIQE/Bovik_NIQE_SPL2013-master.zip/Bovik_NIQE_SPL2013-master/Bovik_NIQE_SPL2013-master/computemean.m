function val = computemean(patch)

val = mean2(patch);