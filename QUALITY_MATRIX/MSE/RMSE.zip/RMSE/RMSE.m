clear all
close all
clc
GT_IMAGE = imread('baby_x2_GT.png');
figure
imshow(GT_IMAGE);
title('GROUND TRUTH IMAGE');

GT_GRAY_SCALE_IMAGE = rgb2gray(GT_IMAGE);
figure
imshow(GT_GRAY_SCALE_IMAGE);
title('GRAY SCALE IMAGE');

SRCNN_IMAGE = imread('baby_x2_bicubic.png');
figure
imshow(SRCNN_IMAGE);
title('SRCNN_IMAGE');

SRCNN_GRAY_SCALE_IMAGE = rgb2gray(SRCNN_IMAGE);
figure
imshow(SRCNN_GRAY_SCALE_IMAGE);
title('SRCNN GRAY SCALE IMAGE');
error = immse(GT_GRAY_SCALE_IMAGE,SRCNN_GRAY_SCALE_IMAGE) 
%error = immse(GT_GRAY_SCALE_IMAGE,GT_GRAY_SCALE_IMAGE) %IF CHECK FORMULA IS CORRECT YOU PUT SAME IMAGE IN
% BOTH RESULT IS ZERO