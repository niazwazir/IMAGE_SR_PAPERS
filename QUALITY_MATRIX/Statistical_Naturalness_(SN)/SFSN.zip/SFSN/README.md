# SFSN
 Implementation of QoMEX 2021 "Image Super-Resolution Quality Assessment: Structural Fidelity Versus Statistical Naturalness"

## Citation
You may cite it in your paper. Thanks a lot.

```
@article{zhou2021image,
  title={Image Super-Resolution Quality Assessment: Structural Fidelity Versus Statistical Naturalness},
  author={Zhou, Wei and Wang, Zhou and Chen, Zhibo},
  journal={arXiv preprint arXiv:2105.07139},
  year={2021}
}
```
