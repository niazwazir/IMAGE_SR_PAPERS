I = imread('Original_Image/baby_x2_GT.png');
Crop = I(100:300,200:400,:); %first number is heightLast number is width
figure;
subplot(211);imshow(I);
axis on
subplot(212);imshow(Crop);
axis on 
imwrite(Crop,'Patches_Created/GT_PATCH_x8.png');%SAVE THE MODEL PATCH IMAGE%%%%%%%%%
