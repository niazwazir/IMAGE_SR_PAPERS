I = imread('Original_Image/baby_x2_bicubic.png'); %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Crop = I(100:300,200:400,:); %first number is heightLast number is width
figure;
subplot(211);imshow(I);
axis on
subplot(212);imshow(Crop)
axis on
imwrite(Crop,'Patches_Created/bicubic.png');%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% CALCULATE THE PSNR AND SSIM
GT = imread('Patches_Created/GT_PATCH_x8.png'); 
ModelImg = imread('Patches_Created/bicubic.png');%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
psnr = compute_psnr(GT,ModelImg);
fprintf('PSNR for =   %f dB\n', psnr);
[ssimval, ssimmap] = ssim(GT,ModelImg);  
fprintf('The SSIM value is %0.3f.\n',ssimval);